-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2019 at 10:49 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `postgraduate`
--

-- --------------------------------------------------------

--
-- Table structure for table `bachelorinformation`
--

CREATE TABLE `bachelorinformation` (
  `card number` varchar(30) NOT NULL,
  `degree` varchar(30) NOT NULL,
  `Role` varchar(30) NOT NULL,
  `General` varchar(30) NOT NULL,
  `College` varchar(30) NOT NULL,
  `Specialization` varchar(30) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `University` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bachelorinformation`
--

INSERT INTO `bachelorinformation` (`card number`, `degree`, `Role`, `General`, `College`, `Specialization`, `Department`, `University`) VALUES
('2098642245677886', '320', 'الاول', 'جيد', 'حاسبات', 'علوم حاسب', 'نظم', 'المنوفيه'),
('-1', '', '', '', '?????', '', '?????', '????????'),
('1', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', 'kjj', 'jnjn', 'nj', 'nhh', 'njj', 'jh', 'h'),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', 'ghghhjhjhjj', '', 'ssssssss', '', '', '', ''),
('', 'ghghhjhjhjj', '', 'ssssssss', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `diploma`
--

CREATE TABLE `diploma` (
  `card number` varchar(30) NOT NULL,
  `Role of Diploma` varchar(30) NOT NULL,
  `Major (Graduate)` varchar(30) NOT NULL,
  `Diploma estimation` varchar(30) NOT NULL,
  `From College (Diploma)` varchar(30) NOT NULL,
  `University (Diploma)` varchar(30) NOT NULL,
  `Graduate Diploma in` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `diploma`
--

INSERT INTO `diploma` (`card number`, `Role of Diploma`, `Major (Graduate)`, `Diploma estimation`, `From College (Diploma)`, `University (Diploma)`, `Graduate Diploma in`) VALUES
('', 'yy', 'bb', '', 'bbb', '', 'nnn'),
('999', 'nnn', '', '', '', '', ''),
('1', '', '', 'nnn', '', '', ''),
('', 'nnn', '', '', '', '', ''),
('-1', '', '', '', '????????', 'bbb', '???'),
('', 'nnn', '', '???', '????????', '????', '???'),
('-1', 'nnn', '12', 'nn', '????????', '', '???'),
('-1', 'nnn', '12', '???', 'bbb', 'bbb', '???'),
('', 'nnnnn', 'nnnnnnn', 'nnnnnnn', 'nnnnn', '', 'nnnnnnn'),
('-1', '', 'ssssssss', 'sddddddddddd', 'sssssssssss', 'ssssssssss', ''),
('-1', 'nnn', '', '', '', 'mmm', ''),
('0', 'nnnxxxxxxxxxxx', '12', 'nn', 'bbb', 'bbb', 'nnnxxxxxxxxxx'),
('-1', 'jjjjjjjjjjjjjjj', '12', 'nn', '????????', 'bbb', 'nnn'),
('-1', 'nnn', '12', 'nn', '????????', 'bbb', 'nnn'),
('1', '?????', '12', 'nn', 'bbb', 'bbb', 'nnn'),
('-1', '????', '????', '??????', '????', '???', '????'),
('', '????', '????', '', '', '', '???'),
('', '?????', '????', '', '', '', ''),
('-1', 'jjjjjjjjjjjjjjj', '', '', '', '', 'nnn'),
('', '', '', '', '', '', ''),
('-1', '', '', '', '', '', ''),
('', '', '', '', '????????', '', ''),
('1', 'jjjjjjjjjjjjjjj', '12', '', '????????', '', ''),
('-1', '', '', '', '', '', 'nnn'),
('', '?????????????????????', '????', '???', '', '', '???'),
('-1', '????', '12', 'nn', 'bbb', 'mmm', 'nnn'),
('', '', '', '', 'nbnnn', '', ''),
('', '', '', '', '    mmmm', '', ''),
('', '', '', '', 'nnnn', 'nnnn', ''),
('-1', 'jjjjjjjjjjjjjjj', '12', 'nn', '', '', 'nnn'),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('-2', 'yy', '12', 'nn', '    mmmm', 'nnnn', 'nnn'),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', '????'),
('-3', '', '', '', '', '', ''),
('99', '', '', '', '', '', ''),
('-1', '????', '', '??????', '?????', '????', ''),
('1', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', 'nj', 'ggh', 'hh', 'ghg', 'gg', 'h'),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `masters`
--

CREATE TABLE `masters` (
  `card degree` varchar(30) NOT NULL,
  `degreemaster` varchar(30) NOT NULL,
  `degreedate` varchar(30) NOT NULL,
  `specialization` varchar(30) NOT NULL,
  `grademaster` varchar(30) NOT NULL,
  `faculty4` varchar(30) NOT NULL,
  `university` varchar(30) NOT NULL,
  `department` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `masters`
--

INSERT INTO `masters` (`card degree`, `degreemaster`, `degreedate`, `specialization`, `grademaster`, `faculty4`, `university`, `department`) VALUES
('', '222', '', 'vvv', 'nnn', '22222', '2222', '2222'),
('', '???? ', '', '???', '???', '?????', '???', '??'),
('-3', '', '', '', '', '', '', ''),
('99', '', '', '', '', '', '', ''),
('4555677', '1244', '7888-06-07', 'yyyy', 'nnn', 'nnn', 'nnhn', 'jjj'),
('-1', '?????', '', '', '', '', '????????', '????????'),
('1', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', 'jkj', 'ff', 'ff', 'ff', 'hh', 'hhg', 'jj'),
('', '', '', '', '', '', '', ''),
('', '', '', '', 'good', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `personal_info`
--

CREATE TABLE `personal_info` (
  `card number` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `birthday` varchar(30) NOT NULL,
  `placeOfBirth` varchar(30) NOT NULL,
  `centre` varchar(30) NOT NULL,
  `Governorate` varchar(30) NOT NULL,
  `Nationality` varchar(30) NOT NULL,
  `Religion` varchar(30) NOT NULL,
  `IssuingCard` varchar(30) NOT NULL,
  `JobFunction` varchar(30) NOT NULL,
  `DateOfCard` varchar(30) NOT NULL,
  `AddressOfJob` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `armySituation` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `personal_info`
--

INSERT INTO `personal_info` (`card number`, `name`, `birthday`, `placeOfBirth`, `centre`, `Governorate`, `Nationality`, `Religion`, `IssuingCard`, `JobFunction`, `DateOfCard`, `AddressOfJob`, `phone`, `armySituation`) VALUES
('23445778899900', 'بلال', '10/9/1998', 'المنوفيه', 'المنوفيه', 'مصر', 'مصري', 'مسلم', 'المنوفيه', 'مبرمج', '11/2/2002', 'مصر', '0654211245667', 'اعفاء'),
('-1', 'ddf', '2019-04-29', 'nnnn', 'bbbnb', 'jkjjk', '', '', '', '?????', '2019-04-30', '?????', '?????', ''),
('1', 'cccc', '', '????', '???', '????', '?????', '', '????', '???', '', '?????', '?????', '?????'),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', 'amiraaa', 'jj', 'kk', 'hh', 'bb', 'uu', 'kk', 'kk', 'jj', 'nn', 'kk', 'jj', 'hjh'),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', 'ayaaaaaaaaaaami', '', '', '', '', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('', 'amiraaaaaaaaya', '', '', '', '', '', '', '', '', '', '', '', ''),
('', 'uuuuu', '', '', '', '', '', '', '', '', '', '', '', ''),
('', 'yyy', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `students_info`
--

CREATE TABLE `students_info` (
  `stud_id` varchar(30) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `sid` varchar(30) NOT NULL,
  `shours` int(11) NOT NULL,
  `sdegree` decimal(10,0) NOT NULL,
  `srate` varchar(30) NOT NULL,
  `sreg_num` int(11) NOT NULL,
  `sdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `sid` int(11) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `sdoctor` varchar(30) NOT NULL,
  `stype` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`sid`, `sname`, `sdoctor`, `stype`) VALUES
(0, ' Design and Analysis of Parall', 'x', 'Fundamentals of CS  '),
(1, 'Selected Topics in Mathematics', 'x', 'Fundamentals of CS'),
(2, 'Digital Forensics ', 'x', 'ai and expert system'),
(3, ' Web Mining ', 'x', 'ai and expert system'),
(4, ' Neural Networks and Genetic A', 'x', 'ai and expert system'),
(5, ' Advanced Robotics ', 'x', 'ai and expert system'),
(6, 'Artificial Intelligence -2', 'x', 'ai and expert system'),
(7, ' 3D Game Development ', 'x', 'Programming Languages  '),
(8, ' Multi-core Programming', 'x', 'Programming Languages'),
(9, ' Advanced Programming Language', 'x', 'Programming Languages'),
(10, ' Quantum computing ', 'x', 'High Performance Computing '),
(11, 'Big Data Analysis and Processi', 'x', 'High Performance Computing'),
(12, 'Distributed Systems Design', 'x', 'High Performance Computing'),
(13, ' Distributed Architectures Mod', 'x', 'High Performance Computing'),
(14, ' Advanced Computer Graphics ', 'x', 'High Performance Computing'),
(15, ' Mobile and Pervasive Computin', 'x', 'High Performance Computing'),
(16, 'Parallel Programming-2 ', 'x', 'High Performance Computing'),
(17, ' Secure Code Practices', 'x', 'Software Engineering '),
(18, ' Advanced Software Engineering', 'x', 'Software Engineering'),
(19, ' Software Quality ', 'x', 'Software Engineering'),
(20, 'Software Engineering -3 ', 'x', 'Software Engineering'),
(21, 'Advanced  Operating System ', 'x', 'System Software '),
(22, ' Operating System-3 ', 'x', 'System Software '),
(23, ' Human- Robot Interaction ', 'x', 'Natural Language Processing '),
(24, ' Natural Language Processing a', 'x', 'Natural Language Processing'),
(25, ' Knowledge Engineering ', 'x', 'Natural Language Processing'),
(26, 'Compiler construction – 2', 'x', 'Natural Language Processing'),
(27, ' Selected Topics in CS ', 'x', 'Selected Topics in CS '),
(28, 'Project ', 'x', 'Selected Topics in CS'),
(29, 'Analysis and Design of Informa', 'x', 'Fundamentals, Systems  Analysi'),
(30, ' Advanced Data Structures ', 'x', 'Fundamentals, Systems  Analysi'),
(31, ' Databases for New Computing P', 'x', 'Database Systems '),
(32, ' Modern Database Models ', 'x', 'Database Systems'),
(33, ' Advanced Database Systems ', 'x', 'Database Systems'),
(34, 'Database Design', 'x', 'Database Systems'),
(35, 'Advanced Distributed Databases', 'x', 'Distributed Data Management '),
(36, ' Advanced Topics in Enterprise', 'x', 'Distributed Data Management'),
(37, 'Data Warehousing ', 'x', 'Distributed Data Management'),
(38, '  Advanced Topics in Data Mana', 'x', 'Management of IS '),
(39, ' E-business ', 'x', 'Management of IS'),
(40, 'Management of Information Syst', 'x', 'Management of IS'),
(41, ' Advanced Topics in Informatio', 'x', 'Web-based IS '),
(42, 'Intelligent Web-based IS ', 'x', 'Web-based IS'),
(43, ' Web Information Processing ', 'x', 'Web-based IS'),
(44, ' Information Storage and Retri', 'x', 'Web-based IS'),
(45, 'Web Programming ', 'x', 'Web-based IS'),
(46, 'Geographic Information System ', 'x', 'Advanced IS '),
(47, 'Data Mining and Applied Analyt', 'x', 'Advanced IS'),
(48, 'Spatial Database Design ', 'x', 'Advanced IS'),
(49, 'Advanced Information Systems E', 'x', 'Advanced IS'),
(50, 'Advanced Information Security ', 'x', 'Advanced IS'),
(51, ' Reasoning with Informatics co', 'x', 'Advanced IS'),
(52, ' Mobile Computing ', 'x', 'IS Applications '),
(53, ' Content Management ', 'x', 'IS Applications'),
(54, ' Data Management in Bioinforma', 'x', 'IS Applications'),
(55, 'IS Applications ', 'x', 'IS Applications'),
(56, 'Project', 'x', 'Selected Topics in IS'),
(57, 'Selected Topics in IS', 'x', 'Selected Topics in IS'),
(58, 'Multimedia Networking ', 'x', 'Computer Networks and Network '),
(59, 'Information Networks-2 ', 'x', 'Computer Networks and Network '),
(60, 'Computer networks-4 ', 'x', 'Computer Networks and Network '),
(61, 'Advanced Topics in Computer Ne', 'x', 'Computer Networks and Network '),
(62, 'Advanced topics in Network man', 'x', 'Computer Networks and Network '),
(63, ' Advanced topics in network se', 'x', 'Computer Networks and Network '),
(64, ' Advanced Topics in Computer V', 'x', 'Computer Vision '),
(65, ' Computer Vision-2 ', 'x', 'Computer Vision'),
(66, ' Image Processing-3  ', 'x', 'Computer Vision'),
(67, 'Digital image processing -2 ', 'x', 'Computer Vision'),
(68, ' Biometrics ', 'x', 'Pattern Recognition '),
(69, ' Advanced Topics in Pattern Re', 'x', 'Pattern Recognition'),
(70, ' Pattern Recognition-2 ', 'x', 'Pattern Recognition'),
(71, 'Pattern Recognition-2', 'x', 'Pattern Recognition'),
(72, 'Virtual Reality-2 ', 'x', 'Computer Graphics and  Virtual'),
(73, ' Network operating system ', 'x', 'Computer Graphics and  Virtual'),
(74, 'Animation ', 'x', 'Computer Graphics and  Virtual'),
(75, ' Web Development-2 ', 'x', 'Web Design and Development '),
(76, ' Advanced Topics in Multimedia', 'x', 'Multimedia  '),
(77, ' Automatic Speech Recognition-', 'x', 'Signal Processing and Speech R'),
(78, 'Speech Recognition-2 ', 'x', 'Signal Processing and Speech R'),
(79, 'Project', 'x', 'Selected Topics in IT '),
(80, 'Selected Topics in IT ', 'x', 'Selected Topics in IT '),
(81, 'Advanced Information Technolog', 'x', 'Selected Topics in IT '),
(82, 'Medical Imaging ', 'x', 'Selected Topics in IT'),
(83, 'Human-Computer Interaction ', 'x', 'Selected Topics in IT'),
(84, ' Computer-Assisted Interventio', 'x', 'Selected Topics in IT'),
(85, 'Computational Cognitive Scienc', 'x', 'Selected Topics in IT'),
(86, 'Operations Research and Decisi', 'x', 'Fundamentals of Systems & Oper'),
(87, ' Advanced production and inven', 'x', 'Project Planning '),
(88, ' Applied Project Management ', 'x', 'Project Planning'),
(89, 'Decision Support Systems ', 'x', 'Project Planning'),
(90, ' Selected topics in Mathematic', 'x', 'Systems Optimization'),
(91, ' Advanced Optimization -1', 'x', 'Systems Optimization'),
(92, 'Linear and Nonlinear Programmi', 'x', 'Systems Optimization'),
(93, ' Advanced Modeling and Simulat', 'x', 'Systems Simulation '),
(94, 'Modeling and Simulation ', 'x', 'Systems Simulation'),
(95, ' Advanced Decision Support Met', 'x', 'Systems Management and Decisio'),
(96, ' Advanced Models of Operations', 'x', 'Systems Management and Decisio'),
(97, ' Service Science, Management a', 'x', 'Systems Management and Decisio'),
(98, ' Advanced Decision and Game Th', 'x', 'Systems Management and Decisio'),
(99, ' Advanced Decision Support Sys', 'x', 'Systems Management and Decisio'),
(100, 'Decision and Game Theory ', 'x', 'Systems Management and Decisio'),
(101, 'Applied Computational Intellig', 'x', 'Intelligent Computations '),
(102, 'Applications of Operations Res', 'x', 'Decision Support Applications '),
(103, 'Applications of Advanced Opera', 'x', 'Decision Support Applications'),
(104, 'Advanced Stochastic Programmin', 'x', 'Decision Support Applications'),
(105, ' Research Topics in  Decision ', 'x', 'Decision Support Applications'),
(106, ' Research Topics in  Operation', 'x', 'Decision Support Applications'),
(107, 'Advanced Topics in  Operations', 'x', 'Decision Support Applications'),
(108, ' Advanced Topics in Informatio', 'x', 'Selected Topics in OD '),
(109, 'Selected Topics in OD ', 'x', 'Selected Topics in OD'),
(110, 'Selected Topics –x in OD ', 'x', 'Selected Topics in OD'),
(111, 'Selected Topics-1in OD ', 'x', 'Selected Topics in OD'),
(112, 'Project', 'x', 'Selected Topics in OD');

-- --------------------------------------------------------

--
-- Table structure for table `subjects_registeration`
--

CREATE TABLE `subjects_registeration` (
  `name` varchar(30) NOT NULL,
  `department` varchar(30) NOT NULL,
  `scientific_degree` varchar(30) NOT NULL,
  `subject1` varchar(30) NOT NULL,
  `subject2` varchar(30) NOT NULL,
  `subject3` varchar(30) NOT NULL,
  `subject4` varchar(30) NOT NULL,
  `subject5` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects_registeration`
--

INSERT INTO `subjects_registeration` (`name`, `department`, `scientific_degree`, `subject1`, `subject2`, `subject3`, `subject4`, `subject5`) VALUES
('', '', '', '', '', '', '', ''),
('as', 'is', 'diploma', 'a', 's', 'j', 'h', 'h'),
('', '', '', '', '', '', '', ''),
('jj', '', 'hh', '', '', '', 'hh', ''),
('', '', '', '', '', '', '', ''),
('qwe', 'ghj', '', '', '', '', '', ''),
('aya', 'cs', 'diploma', 'a', 'b', 'c', 'f', 'd'),
('amera', '', '', '', '', '', '', ''),
('ddd', '', '', '', '', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
