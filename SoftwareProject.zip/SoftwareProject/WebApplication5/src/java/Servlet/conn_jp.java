package Servlet;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conn_jp {

    public static Connection getconnection() throws SQLException {
        Connection conn=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/postgraduate", "root", "");

        } catch (ClassNotFoundException ex) {
            System.out.println("error");
        }

   return conn; } 
}
