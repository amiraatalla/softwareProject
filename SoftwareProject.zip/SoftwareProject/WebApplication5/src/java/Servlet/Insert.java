package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SkyTop
 */
public class Insert extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            String name = request.getParameter("name");
            String department = request.getParameter("department");
            String scientific_degree = request.getParameter("scientific_degree");
            String subject1 = request.getParameter("subject1");
            String subject2 = request.getParameter("subject2");
            String subject3 = request.getParameter("subject3");
            String subject4 = request.getParameter("subject4");
            String subject5 = request.getParameter("subject5");
            
            Connection conn = conn_jp.getconnection();
            System.out.println("connect");
            
            java.sql.PreparedStatement st3 = conn.prepareStatement("insert into subjects_registeration values (?,?,?,?,?,?,?,?) ;");
            
            st3.setString(1, name);
            st3.setString(2, department);
            st3.setString(3, scientific_degree);
            st3.setString(4, subject1);
            st3.setString(5, subject2);
            st3.setString(6, subject3);
            st3.setString(7, subject4);
            st3.setString(8, subject5);
            
            st3.execute();
            
            System.out.println("done!!");
        } catch (SQLException ex) {
            Logger.getLogger(Insert.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PrintWriter out = response.getWriter();
        out.print("inserted successfully!!!");
        
    }
}
