package Servlet;

import com.mysql.jdbc.Connection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class debloma extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
            response.setContentType("text/html;charset=UTF-8");
            System.out.println("ghjkk");

            String dept = request.getParameter("dept");

            String armySituation = request.getParameter("armySituation");

            String idNumber = request.getParameter("idNumber");
            String postgraduatein = request.getParameter("postgraduatein");
            String name = request.getParameter("name");
            String birthDate = request.getParameter("birthDate");
            String placeOfBirth = request.getParameter("placeOfBirth");
            String center = request.getParameter("center");
            String mohafza = request.getParameter("mohafza");
            String nationality = request.getParameter("nationality");
            String religion = request.getParameter("religion");
            String idCard = request.getParameter("idCard");
            String idSrc = request.getParameter("idSrc");
            String idDate = request.getParameter("idDate");
            String job = request.getParameter("job");
            String address = request.getParameter("address");
            String phone = request.getParameter("phone");
            String license = request.getParameter("license");
            String floor = request.getParameter("floor");
            String grade = request.getParameter("grade");

            String spe2 = request.getParameter("spe2");
            String grid2 = request.getParameter("grid2");

            String facultyDept = request.getParameter("facultyDept");
            String departmentGrade = request.getParameter("departmentGrade");
            String faculty = request.getParameter("faculty");
            String university = request.getParameter("university");
            String license2 = request.getParameter("license2");
            String floor2 = request.getParameter("floor2");
            String spe = request.getParameter("spe");
            String grid = request.getParameter("grid");
            String faculty2 = request.getParameter("faculty2");
            String university2 = request.getParameter("university2");
            String faculty3 = request.getParameter("faculty3");
            String university3 = request.getParameter("university3");
            String signture = request.getParameter("signture");
            String science = request.getParameter("science");
            String idDategrade = request.getParameter("idDategrade");
            String master = request.getParameter("master");

//            HttpSession session = request.getSession();
//            session.setAttribute("name", name);

           
            //  Statement st = (Statement) x.createStatement();
            // st.executeUpdate("insert into diploma values('" + idCard + "','" + floor2 + "','" + spe + "','" + grid + "','" + faculty2 + "','" + university2 + "','" + license2 + "'));");
            //#########
            //Table2
            
            Connection conn = (Connection) conn_jp.getconnection();
            
            java.sql.PreparedStatement st = conn.prepareStatement("insert into  diploma values (?,?,?,?,?,?,?) ;");
            st.setString(1, idCard);
            st.setString(2, floor2);
            st.setString(3, spe);
            st.setString(4, grid);
            st.setString(5, faculty2);
            st.setString(6, university2);
            st.setString(7, license2);
            st.execute();
            System.out.println("oooooooook");
            //Table1
            // (card number,Bachelor's / Bachelor's Degree in,Role (BA),General appreciation Bachelor,College Bachelor,Specialization Assessment (BA),Division (Bachelor),University (Bachelor),Photo Bachelor degree)
            java.sql.PreparedStatement st2 = conn.prepareStatement("insert into  bachelorinformation values (?,?,?,?,?,?,?,?) ;");

            st2.setString(1, idCard);
            st2.setString(2, license);
            st2.setString(3, floor);
            st2.setString(4, grade);
            st2.setString(5, faculty);
            st2.setString(6, departmentGrade);
            st2.setString(7, facultyDept);
            st2.setString(8, university);

            st2.execute();
            //Table3

            java.sql.PreparedStatement st3 = conn.prepareStatement("insert into masters values (?,?,?,?,?,?,?,?) ;");

            st3.setString(1, idCard);
            st3.setString(2, master);
            st3.setString(3, idDategrade);
            st3.setString(4, spe2);
            st3.setString(5, grid2);

            st3.setString(6, faculty3);
            st3.setString(7, university3);
            st3.setString(8, science);
            st3.execute();
            //(	card number,name,fathername,	birthday,Place of birth (village),	center,Governorate,Nationality,	Religion,	Issuing card,Job Function,Date of issuing the card,Title (job),phone number,Photo position of recruitment,Copy of the card)
            //Table4
            java.sql.PreparedStatement st4;
            st4 = conn.prepareStatement("insert into personal_info values (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ;");
            st4.setString(1, idCard);
            st4.setString(2, name);
            st4.setString(3, birthDate);
            st4.setString(4, placeOfBirth);
            st4.setString(5, center);
            st4.setString(6, mohafza);
            st4.setString(7, nationality);
            st4.setString(8, religion);
            st4.setString(9, idSrc);
            st4.setString(11, idDate);

            st4.setString(10, job);
            st4.setString(14, armySituation);
            st4.setString(12, address);
            st4.setString(13, phone);

            st4.execute();

        } catch (SQLException ex) {
            Logger.getLogger(debloma.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("connect");
        PrintWriter out = response.getWriter();
        out.print("Inserted Successfully");
    }
 
}
