/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author aya
 */
public class masters extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            
          String idCard = request.getParameter("idCard");
                  String master = request.getParameter("master");
        String idDategrade = request.getParameter("idDategrade");
      String spe2 = request.getParameter("spe2");
        String grid2 = request.getParameter("grid2");
          
           String faculty3 = request.getParameter("faculty3");
        String university3 = request.getParameter("university3");
        String science = request.getParameter("science");
          
          
                      java.sql.Connection conn;
          
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/postgraduate", "root", "");
          

          
           java.sql.PreparedStatement st3 = conn.prepareStatement("insert into masters values (?,?,?,?,?,?,?,?) ;");

            st3.setString(1, idCard);
            st3.setString(2, master);
            st3.setString(3, idDategrade);
              st3.setString(4, spe2);
            st3.setString(5, grid2);
            
            st3.setString(6, faculty3);
            st3.setString(7, university3);
            st3.setString(8, science);
            st3.execute();
        
        } catch (SQLException ex) {
            Logger.getLogger(masters.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(masters.class.getName()).log(Level.SEVERE, null, ex);
        }
       

}
}